<div class="footer">
    <div>© Student Services, 2020
        <a href="/StudentServices/index.php">Home</a>
        <a href="/StudentServices/View/Veelgesteldevragen/View.php">FAQ</a>
        <a href="/StudentServices/ClientSide/Contact.php">Contact</a>
    </div>
</div>