voer in deze map de shell uit of navigeer via de phpstorm terminal naar deze map
C:/xampp/htdocs/StudentServices/Unittest/

voer het commando uit in de shell composer update (hoeft maar eenmalig)
daarna kunnen je de testen uitvoeren door 

php phpunit.phar 

kijk voor de rest van de testen in de map Tests