<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Bevestig StudentServices account</title>
    <meta name="description" content="bevesting link">
    <meta name="author" content="Student Services">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="/StudentServices/JS/bevestigenaccount.js"></script>
    <!--  <link rel="stylesheet" href="style.css">-->
</head>




<body onload = vertifyemaillink()>


</body>
<script>
   // window.onload = vertifyemaillink;
</script>
</html>

